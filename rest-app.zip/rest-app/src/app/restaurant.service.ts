import { Injectable } from '@angular/core';
import { IRestaurant } from './restaurant';
import {AppModule} from './app.module';
@Injectable()
export class RestaurantService {

  constructor() { }

  getRestaurants() :IRestaurant[]{
    return [{
      "restaurantId": 1,
      "restaurantTitle": "Mogli",
      "restaurantCity": "Delhi",
      "restaurantState": "deLhi",
      "starRating": 3.4,
      "imageUrl": "https://i.pinimg.com/originals/03/4f/75/034f75c06a06de6635af8f24b5808096.png"
    },
    {
    "restaurantId": 2,
    "restaurantTitle": "Haldiram",
    "restaurantCity": "Nagpur",
    "restaurantState": "Maharashtra",
    "starRating": 2.5,
    "imageUrl": "http://www.design-worldwide.com/images/clients/big/yochina6big.jpg"
    },
    {
    "restaurantId": 3,
    "restaurantTitle": "Yo China",
    "restaurantCity": "Noida",
    "restaurantState": "uttar pradesh",
    "starRating": 4,
    "imageUrl": "http://www.design-worldwide.com/images/clients/big/yochina6big.jpg"
    }];
  }
}
