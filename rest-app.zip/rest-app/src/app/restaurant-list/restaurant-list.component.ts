import { Component, OnInit } from '@angular/core';
import { IRestaurant } from '../restaurant';
import { RestaurantService } from '../restaurant.service';

@Component({
  selector: '.app-restaurant-list',
  templateUrl: './restaurant-list.component.html',
  styleUrls: ['./restaurant-list.component.css']
})
export class RestaurantListComponent implements OnInit {

  listFilter: string='mogli';
  imageWidth:number = 150;
  pageTitle :string ="RMS";
  restaurants: IRestaurant[];


  constructor(public _restService : RestaurantService) {
    
   }

  ngOnInit() {
    this.restaurants = this._restService.getRestaurants();
  
  }

}
