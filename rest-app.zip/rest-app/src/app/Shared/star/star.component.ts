import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
   
  selector: 'app-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.css']
})
export class StarComponent implements OnInit , OnChanges {
starWidth : number ;
@Input()  rating :number;
  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(){
    this.starWidth = this.rating * 70/5;
  }

}
